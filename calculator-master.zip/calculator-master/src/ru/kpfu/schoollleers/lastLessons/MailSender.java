package ru.kpfu.schoollleers.lastLessons;

import ru.kpfu.schoollleers.karim.Mail;

public class MailSender {
    Mail mail;
    public static void setMain(Mail mail){
        sendMessage(mail);
    }
    public static void sendMessage(Mail mail){

    }

}
